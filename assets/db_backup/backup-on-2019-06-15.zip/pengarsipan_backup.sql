#
# TABLE STRUCTURE FOR: penjualan
#

DROP TABLE IF EXISTS `penjualan`;

CREATE TABLE `penjualan` (
  `kd_barang` varchar(30) NOT NULL,
  `tanggal` varchar(30) NOT NULL,
  PRIMARY KEY (`kd_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `penjualan` (`kd_barang`, `tanggal`) VALUES ('A3', '01 Mei 2019');
INSERT INTO `penjualan` (`kd_barang`, `tanggal`) VALUES ('A4', '01 Mei 2019');
INSERT INTO `penjualan` (`kd_barang`, `tanggal`) VALUES ('A5', '01 Mei 2019');
INSERT INTO `penjualan` (`kd_barang`, `tanggal`) VALUES ('A6', '01 Mei 2019');


#
# TABLE STRUCTURE FOR: ready_barang
#

DROP TABLE IF EXISTS `ready_barang`;

CREATE TABLE `ready_barang` (
  `kd_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `size` varchar(4) DEFAULT NULL,
  `harga` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`kd_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ready_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('233444', 'purel', 'S', '11111');
INSERT INTO `ready_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('43553', 'ayam kampus', 'S', '3333');
INSERT INTO `ready_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A002', 'Jaket YYYY', 'XL', '250000');
INSERT INTO `ready_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A003', 'Celana FTHUU', 'L', '210000');
INSERT INTO `ready_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A004', 'BAJU HGUBKM', 'M', '270000');
INSERT INTO `ready_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A005', 'Jaket VVHHUU', 'XXL', '290000');


#
# TABLE STRUCTURE FOR: riwayat_barang
#

DROP TABLE IF EXISTS `riwayat_barang`;

CREATE TABLE `riwayat_barang` (
  `kd_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `size` varchar(4) DEFAULT NULL,
  `harga` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`kd_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `riwayat_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('233444', 'purel', 'S', '11111');
INSERT INTO `riwayat_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('43553', 'ayam kampus', 'S', '3333');
INSERT INTO `riwayat_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A001', 'Baju XXXXX', 'M', '200000');
INSERT INTO `riwayat_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A002', 'Jaket YYYY', 'XL', '250000');
INSERT INTO `riwayat_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A003', 'Celana FTHUU', 'L', '210000');
INSERT INTO `riwayat_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A004', 'BAJU HGUBKM', 'M', '270000');
INSERT INTO `riwayat_barang` (`kd_barang`, `nama_barang`, `size`, `harga`) VALUES ('A005', 'Jaket VVHHUU', 'XXL', '290000');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (4, 'bisa', 'bisa', '$2y$10$l60HuzdWwknkKAxtYOHV7ulERiueGJ.5ouqh6iHQkb/j0vAfeOhae');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (5, 'aku', 'aku', '$2y$10$G31UgCWSXIT8CEJ1/63ut.kkWNqynOhIBTTAxylJ0tQUY6VqDWm4K');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (6, 'semua', 'semua', '$2y$10$0AyUXgR/hfmumCQcnGmbs.pbw11z9eX2ZIGPp1Do8oHPQtmJVTLMy');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (7, 'M Hijrah Mauludi', 'mhijrah276@gmail.com', '$2y$10$I9BqreKbbp1Gt7UkyQPsruMrUzc8Fs4.xLsNOqN06amX9leL1yTIu');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (8, 'sukses', 'sukses', '$2y$10$w6VbB9hxi8u/tQYsBHgGLux0GVA9Rm8IbV6g4EYK7PiJbxzw8XO4.');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (9, 'iya', 'iya', '$2y$10$yQw/Y1dZcsIHop39qQr4BeWklSp0Elc0GTliUwNNXWTVAylv8Vl8S');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (10, 'ya', 'ya', '$2y$10$Txu9vYeGEfs6ofD7syobW.1f5cQ/Q1PUK/qrXMaBc5REA8ac.Ww5a');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (11, 'tes', 'tes', '$2y$10$G5f1qlTB5.d8QjH/oPIakuUkPwwAiAOlo0oxdUNX4gpM29sBZS02a');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (12, 'bm', 'bm', '$2y$10$WAVfIS9AtGSogfArxLrlOeHueZewOTcsjSAv1BTOWzsKDpF5D1iti');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (13, 'bm', 'bm@gmail.com', '$2y$10$U/AdTlE1x5irau8yDyYqzu93a2g0/AvBRzhAKemhwSI8RK/vqqno.');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (14, 'uoi', 'uoi@gmail.com', '$2y$10$u83QXDImPNHhAv7zS.P1peuY.WJ3joI0talun.QMloZRW2cbaotwm');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (15, '', '', '$2y$10$kfm3auvr87IZ9CwGJyH8EO279tUG0FcWA.LArgHFLibAkaFCTmaGe');
INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES (16, 'davidhelmi', 'davidhelmi@gmail.com', '$2y$10$sh2idEhLFAygfy5MZmhLue6AsFdQh75LGXtZuAwRl21NVWcswyWPK');


